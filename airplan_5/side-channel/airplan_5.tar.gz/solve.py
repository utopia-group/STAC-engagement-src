#!/usr/bin/python    

import math, sys

user=int(sys.argv[1])
n = (34 - math.sqrt(34*34+4*10*(user-3163)))/(-2*10)
print int(n)
